# ICE Scoring Model

_Last updated: 2025-04-13_

The **ICE Model** helps teams prioritize initiatives based on three criteria:

- **Impact** – How much value it will deliver
- **Confidence** – How sure you are of the outcome
- **Ease** – How easy it is to execute

Each scored from 1–10, then multiplied:  
**ICE = Impact × Confidence × Ease**

Great for quick prioritization in lean teams or growth experiments.

📘 [Read more](https://growthhackers.com/growth-studies/prioritization-ice-score)

![ICE Scoring](../../images/ice_scoring.png)