# The Hook Model

_Last updated: 2025-04-13_

Coined by **Nir Eyal**, the **Hook Model** explains how habit-forming products keep users coming back by triggering behavior loops.

### The 4-Step Loop:
1. **Trigger** – Cue that prompts behavior (external or internal)
2. **Action** – Simple behavior in anticipation of reward
3. **Variable Reward** – Unpredictable feedback that builds engagement
4. **Investment** – Effort that increases likelihood of returning

Used by products like Instagram, Twitter, and TikTok to create user habits.

📘 [Read more](https://www.nirandfar.com/hooked/)  
![Hook Model](../../images/hook_model.png)