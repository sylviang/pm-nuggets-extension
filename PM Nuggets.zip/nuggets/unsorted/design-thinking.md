# Design Thinking

_Last updated: 2025-04-13_

**Design Thinking** is a user-centered problem-solving approach based on empathy, ideation, and iteration.

### The 5 phases:
1. Empathize
2. Define
3. Ideate
4. Prototype
5. Test

It encourages divergent thinking and experimentation to create solutions that are both desirable and feasible.

📘 [Read more](https://www.ideou.com/pages/design-thinking)

![Design Thinking](../../images/design_thinking.png)