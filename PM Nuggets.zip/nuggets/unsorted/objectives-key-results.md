# Objectives and Key Results (OKRs)

_Last updated: 2025-04-13_

**OKRs** are a goal-setting framework used by teams and companies to set clear objectives and track measurable results.

### Format:
- **Objective**: What you want to achieve (inspiring)
- **Key Results**: How you'll measure success (specific & time-bound)

### Benefits:
- Aligns teams and strategy
- Drives focus and accountability
- Encourages ambitious but trackable progress

📘 [Read more](https://www.whatmatters.com/)

![OKRs](../../images/okrs.png)