# Parkinson's Law

_Last updated: 2025-04-13_

**Parkinson’s Law** states: *“Work expands to fill the time available for its completion.”*

In product teams, this can lead to:
- Over-polishing
- Unnecessary meetings
- Delayed decisions or launches

Use timeboxing, deadlines, and lean MVPs to fight Parkinson's Law and ship faster.

📘 [Read more](https://en.wikipedia.org/wiki/Parkinson%27s_law)

![Parkinson's Law](../../images/parkinsons_law.png)