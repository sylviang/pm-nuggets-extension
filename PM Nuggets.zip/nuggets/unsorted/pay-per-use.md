# Pay-per-Use

_Last updated: 2025-04-13_

The **pay-per-use** model charges users based on actual usage instead of a flat fee. It increases fairness and accessibility, especially for low-frequency or seasonal users.

### Pros:
- Lower entry barrier
- Aligns cost with value

### Common in:
- Cloud services (e.g., AWS)
- Utilities, APIs, mobility platforms

📘 [Read more](https://hbr.org/2019/11/the-subscription-model-isnt-right-for-every-business)

![Pay per Use](../../images/pay_per_use.png)