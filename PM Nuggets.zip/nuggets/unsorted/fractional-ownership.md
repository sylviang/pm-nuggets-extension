# Fractional Ownership

_Last updated: 2025-04-13_

**Fractional ownership** allows multiple people to share ownership of a product or asset (e.g., real estate, luxury items, software licenses).

This model lowers the barrier to entry and spreads costs across users.

### Applications in product:
- Co-owned subscriptions or usage rights
- Tokenized asset sharing (e.g. NFTs, Web3)
- Crowdfunding or micro-investing platforms

📘 [Read more](https://hbr.org/2021/09/is-fractional-ownership-the-future-of-asset-management)

![Fractional Ownership](../../images/fractional_ownership.png)