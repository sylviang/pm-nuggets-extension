# Customer Satisfaction Score (CSAT)

_Last updated: 2025-04-13_

**CSAT** gauges how satisfied users are with a specific interaction or experience, typically via a 1–5 or 1–10 rating scale.

### Formula:
CSAT = (Number of Positive Responses ÷ Total Responses) × 100

Used in:
- Post-support surveys
- Product feedback loops
- Onboarding assessments

📘 [Read more](https://www.qualtrics.com/experience-management/customer/customer-satisfaction-score/)

![CSAT](../../images/csat.png)