# Black Swan Events

_Last updated: 2025-04-13_

Coined by Nassim Nicholas Taleb, **Black Swan Events** are rare, unpredictable occurrences that have a massive impact — and are often rationalized in hindsight as if they were expected.

### Characteristics:
1. **Rarity** – Extremely difficult to predict
2. **Impact** – Wide-reaching, disproportionate consequences
3. **Retrospective predictability** – We tell stories to explain them after they happen

### Examples:
- 9/11
- COVID-19
- The rise of the internet
- Financial crashes

### Why it matters in Product Management:
- Many breakthroughs (or failures) are Black Swans
- Over-forecasting is dangerous — focus on **resilience**, **adaptability**, and **optionality**
- Build for **uncertainty**, not precision

📘 [Read more](https://en.wikipedia.org/wiki/Black_swan_theory)

![Black Swan Events](../../images/black_swan_events.png)