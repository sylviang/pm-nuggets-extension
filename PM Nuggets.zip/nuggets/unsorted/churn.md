# Churn

_Last updated: 2025-04-13_

**Churn** refers to the percentage of users or revenue lost over a given period.

### Types:
- **Customer churn**: users leaving
- **Revenue churn**: lost MRR or ARR

### Formula:
Churn rate = (Lost users or revenue ÷ Total at start) × 100

Reducing churn improves lifetime value, retention, and growth.

📘 [Read more](https://www.paddle.com/resources/guides/customer-churn-rate)

![Churn](../../images/churn.png)