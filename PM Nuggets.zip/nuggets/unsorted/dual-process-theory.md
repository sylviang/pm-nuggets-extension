# Dual Process Theory

_Last updated: 2025-04-13_

**Dual Process Theory** suggests there are two systems in human decision-making:

- **System 1**: Fast, intuitive, emotional
- **System 2**: Slow, rational, deliberate

PMs can design better products by understanding when users rely on instinct vs. logic — especially in onboarding, pricing, or choices.

📘 [Read more](https://en.wikipedia.org/wiki/Dual_process_theory)

![Dual Process Theory](../../images/dual_process_theory.png)