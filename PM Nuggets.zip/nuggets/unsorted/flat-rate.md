# Flat Rate

_Last updated: 2025-04-13_

A **flat rate** pricing model charges a fixed amount regardless of usage, time, or volume. It provides simplicity and predictability for both the user and the business.

### Pros:
- Easy to understand and budget for
- Encourages consistent usage
- Great for products with similar value per user

### Common in:
- SaaS subscriptions
- Telecom plans
- Delivery services

📘 [Read more](https://www.chargebee.com/resources/guides/pricing-models/)

![Flat Rate Pricing](../../images/flat_rate.png)