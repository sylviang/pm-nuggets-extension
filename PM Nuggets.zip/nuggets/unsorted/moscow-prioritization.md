# MoSCoW Prioritization

_Last updated: 2025-04-13_

**MoSCoW** is a simple prioritization method for managing requirements and features:

- **Must have**
- **Should have**
- **Could have**
- **Won’t have (for now)**

It helps stakeholders align on scope and trade-offs during roadmap planning or sprint prioritization.

📘 [Read more](https://www.agilebusiness.org/page/projectframework_moscow)

![MoSCoW Prioritization](../../images/moscow_prioritization.png)