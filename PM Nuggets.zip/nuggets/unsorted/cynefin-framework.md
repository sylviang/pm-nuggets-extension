# Cynefin Framework

_Last updated: 2025-04-13_

Created by **Dave Snowden**, the **Cynefin Framework** helps leaders understand the context of problems and adapt their decision-making accordingly.

### Five Domains:
1. **Clear** – Obvious cause and effect → Best practices
2. **Complicated** – Expert analysis required → Good practices
3. **Complex** – Unclear cause and effect → Probe–Sense–Respond
4. **Chaotic** – No patterns → Act–Sense–Respond
5. **Confused** – Not yet categorized

Helps PMs and teams navigate uncertainty, especially in product discovery and strategy.

📘 [Read more](https://thecynefin.co/about-us/about-cynefin-framework/)  
![Cynefin Framework](../../images/cynefin_framework.png)