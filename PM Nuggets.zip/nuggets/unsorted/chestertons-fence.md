# Chesterton's Fence

_Last updated: 2025-04-13_

**Chesterton’s Fence** is a mental model that warns against removing or changing a system without understanding why it exists in the first place.

> “Do not remove a fence until you know why it was put up.”

### Why it matters in Product Management:
- Avoid breaking useful legacy processes or features
- Encourages asking: *“What problem was this solving?”*
- Supports thoughtful iteration and refactoring

Use it in product audits, deprecation decisions, and redesigns.

📘 [Read more](https://en.wikipedia.org/wiki/Wikiquote:Chesterton%27s_fence)

![Chesterton's Fence](../../images/chestertons_fence.png)