# Cost of Delay

_Last updated: 2025-04-13_

**Cost of Delay (CoD)** quantifies the financial impact of delaying a project or feature.

It helps prioritize work by focusing on opportunity cost — what value is lost over time.

### CoD is used in:
- WSJF calculations
- Lean portfolio management
- Strategic roadmap trade-offs

📘 [Read more](https://blackswanfarming.com/what-is-cost-of-delay/)

![Cost of Delay](../../images/cost_of_delay.png)