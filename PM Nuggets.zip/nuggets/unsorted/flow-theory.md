# Flow Theory

_Last updated: 2025-04-13_

**Flow**, coined by psychologist Mihaly Csikszentmihalyi, is a mental state of total immersion, focus, and satisfaction in an activity.

### Why it matters in UX:
- Align challenge level with user skill
- Minimize distractions and interruptions
- Create seamless feedback loops

Products that induce flow (e.g., gaming, learning, productivity tools) often enjoy higher retention and engagement.

📘 [Read more](https://en.wikipedia.org/wiki/Flow_(psychology))

![Flow Theory](../../images/flow_theory.png)