# Big Visible Information Radiator (BVIR)

_Last updated: 2025-04-13_

**BVIR** is a large, public display of key project information (e.g. burndown charts, WIP limits, roadmaps). It promotes transparency, alignment, and accountability.

Used in:
- Scrum team boards
- PI planning walls
- OKR progress displays

📘 [Read more](https://www.agilealliance.org/glossary/information-radiator/)

![BVIR](../../images/bvir.png)