# Customer Acquisition Cost (CAC)

_Last updated: 2025-04-13_

**CAC** measures how much it costs to acquire a new customer. It’s critical for understanding your unit economics and marketing efficiency.

### Formula:
CAC = Total acquisition cost ÷ Number of new customers

### Why it matters:
- Helps evaluate paid marketing and sales ROI
- Must be balanced against LTV (Lifetime Value)
- Key to sustainable growth

📘 [Read more](https://www.chargebee.com/resources/guides/customer-acquisition-cost/)

![Customer Acquisition Cost](../../images/cac.png)