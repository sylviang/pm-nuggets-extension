# Logos, Pathos, and Ethos

_Last updated: 2025-04-13_

Aristotle’s persuasive appeals — **Logos (logic), Pathos (emotion), and Ethos (credibility)** — help PMs craft compelling narratives for users and stakeholders.

- **Logos**: Use data, charts, and logic
- **Pathos**: Appeal to values and emotions
- **Ethos**: Build authority and trust

Apply this in pitch decks, roadmaps, and user messaging.

📘 [Read more](https://en.wikipedia.org/wiki/Modes_of_persuasion)

![Logos Pathos Ethos](../../images/logos_pathos_ethos.png)