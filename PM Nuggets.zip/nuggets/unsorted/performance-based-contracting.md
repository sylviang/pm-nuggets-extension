# Performance-Based Contracting

_Last updated: 2025-04-13_

In **performance-based contracting**, the vendor is paid based on results rather than effort or time.

This model incentivizes outcomes over outputs and is often used in:
- Government procurement
- SaaS success-based pricing
- Vendor-client SLAs with KPIs

It shifts accountability and risk while aligning both sides to shared goals.

📘 [Read more](https://www.ncmahq.org/Shared_Content/CM-Magazine/CM-Magazine-March-2021/Feature-Performance-Based-Contracting.aspx)

![Performance-Based Contracting](../../images/performance_based_contracting.png)