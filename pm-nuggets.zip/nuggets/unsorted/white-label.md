# White Label

_Last updated: 2025-04-13_

A **white-label product** is created by one company and rebranded/resold by another.

Used in:
- B2B platforms and tools
- Marketplaces and payment systems
- API-first products

It helps companies scale without building everything in-house.

📘 [Read more](https://www.investopedia.com/terms/w/white-label-product.asp)

![White Label](../../images/white_label.png)