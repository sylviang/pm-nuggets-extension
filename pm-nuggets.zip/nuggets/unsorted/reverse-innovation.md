# Reverse Innovation

_Last updated: 2025-04-13_

**Reverse innovation** is when innovations developed for emerging markets are later adapted for developed ones.

This flips the traditional model — instead of trickle-down innovation, it flows bottom-up.

### PM implications:
- Design for constraints first
- Test affordability and scalability
- Create globally relevant products

📘 [Read more](https://hbr.org/2009/04/how-ge-is-disrupting-itself)

![Reverse Innovation](../../images/reverse_innovation.png)