# Cannibalization

_Last updated: 2025-04-13_

**Cannibalization** occurs when a new product or feature takes users or revenue away from an existing one in your portfolio.

It’s not always bad — it can be part of smart product evolution.

### PMs must consider:
- Net impact on revenue or LTV
- Timing and messaging
- Whether you’re gaining share or just shifting it

📘 [Read more](https://hbr.org/2005/05/strategies-for-competitive-cannibalization)

![Cannibalization](../../images/cannibalization.png)