# Eisenhower Matrix

_Last updated: 2025-04-13_

The **Eisenhower Matrix** (also called the Urgent-Important Matrix) helps prioritize tasks based on **urgency** and **importance**.

It’s divided into 4 quadrants:
1. **Do First** – Important & Urgent
2. **Schedule** – Important but Not Urgent
3. **Delegate** – Urgent but Not Important
4. **Eliminate** – Neither Urgent nor Important

### Why it matters for Product Managers:
- Helps cut through noise during roadmapping or sprint planning
- Reduces reactivity by focusing on impact
- Promotes strategic time use

📘 [Read more](https://www.eisenhower.me/eisenhower-matrix/)

![Eisenhower Matrix](../../images/eisenhower_matrix.png)