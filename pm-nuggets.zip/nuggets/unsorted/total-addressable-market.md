# Total Addressable Market (TAM)

_Last updated: 2025-04-13_

**TAM** is the total revenue opportunity available if your product achieved 100% market share. It's the top-down estimation of your market potential.

TAM is useful for:
- Sizing investor opportunity
- Setting product growth goals
- Deciding which segments to prioritize

Often broken down further into **SAM** (Serviceable Available Market) and **SOM** (Serviceable Obtainable Market).

📘 [Read more](https://www.ycombinator.com/library/6h-how-to-calculate-your-tam-sam-and-som)

![TAM](../../images/total_addressable_market.png)