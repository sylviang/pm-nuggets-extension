# Dual Track Agile

_Last updated: 2025-04-13_

**Dual Track Agile** separates product development into two parallel activities:
- **Discovery** (what to build)
- **Delivery** (how to build it)

It ensures you're building the right thing before building the thing right.

Benefits:
- Reduces waste
- Aligns discovery with execution
- Enables continuous learning and iteration

Popularized by Marty Cagan and Teresa Torres.

📘 [Read more](https://www.svpg.com/dual-track-agile/)

![Dual Track Agile](../../images/dual_track_agile.png)