# Captive Product Pricing

_Last updated: 2025-04-13_

**Captive product pricing** involves selling a base product at a low price and charging premiums for necessary complements.

Examples:
- Razor and blades
- Printers and ink cartridges
- Gaming consoles and games

PMs can use this strategy to build lock-in and recurring revenue from accessories or services.

📘 [Read more](https://www.investopedia.com/terms/c/captive-product-pricing.asp)

![Captive Product Pricing](../../images/captive_product_pricing.png)