# Monthly Recurring Revenue (MRR)

_Last updated: 2025-04-13_

**MRR** is the predictable revenue a company expects to earn every month from active subscriptions.

### Why it matters:
- Core metric for SaaS businesses
- Forecasts growth and cash flow
- Tracks expansion and churn

### Common MRR types:
- New MRR
- Expansion MRR
- Churned MRR
- Net MRR

📘 [Read more](https://www.chartmogul.com/blog/mrr/)

![MRR](../../images/mrr.png)