# Business Model Canvas (BMC)

_Last updated: 2025-04-13_

The **Business Model Canvas** is a one-page visual tool for describing how your business creates, delivers, and captures value.

### 9 Building Blocks:
1. Customer Segments
2. Value Propositions
3. Channels
4. Customer Relationships
5. Revenue Streams
6. Key Resources
7. Key Activities
8. Key Partnerships
9. Cost Structure

Use it to brainstorm, align stakeholders, or test hypotheses.

📘 [Read more](https://www.strategyzer.com/canvas/business-model-canvas)

![Business Model Canvas](../../images/bmc.png)