# Prospect Theory

_Last updated: 2025-04-13_

**Prospect Theory**, developed by Daniel Kahneman and Amos Tversky, explains how people make decisions under uncertainty — often irrationally.

Key insight: **Losses hurt more than equivalent gains feel good**.

### PM application:
- Design pricing and upgrade flows with perceived value in mind
- Frame benefits vs. losses carefully
- Helps in A/B testing messaging or conversion nudges

📘 [Read more](https://en.wikipedia.org/wiki/Prospect_theory)

![Prospect Theory](../../images/prospect_theory.png)