# Weighted Shortest Job First (WSJF)

_Last updated: 2025-04-13_

**WSJF** is a prioritization method from the Scaled Agile Framework (SAFe) that helps teams deliver maximum economic benefit quickly.

### Formula:
WSJF = (User-Business Value + Time Criticality + Risk Reduction) / Job Size

### Why it works:
- Promotes high-impact, low-effort delivery
- Reduces delay cost
- Encourages alignment across stakeholders

Used in agile roadmapping, backlog grooming, and lean portfolio management.

📘 [Read more](https://scaledagileframework.com/wsjf/)

![WSJF](../../images/wsjf.png)