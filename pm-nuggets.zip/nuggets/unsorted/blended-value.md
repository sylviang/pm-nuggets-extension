# Blended Value

_Last updated: 2025-04-13_

**Blended value** is the idea that economic, social, and environmental outcomes can be pursued together — not separately.

PMs embracing blended value:
- Prioritize sustainable outcomes
- Align with ethical innovation
- Serve broader stakeholder needs

This concept is key for ESG, govtech, and purpose-driven product strategies.

📘 [Read more](https://www.blendedvalue.org/)

![Blended Value](../../images/blended_value.png)