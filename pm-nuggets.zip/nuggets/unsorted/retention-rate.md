# Retention Rate

_Last updated: 2025-04-13_

**Retention Rate** measures how many users return to your product over time. It’s one of the most critical indicators of product value and stickiness.

### Formula:
Retention = (Users remaining at end of period ÷ Users at start of period) × 100

Used in:
- Cohort analysis
- Churn prediction
- Lifecycle tracking

📘 [Read more](https://www.mixpanel.com/blog/retention-rate/)

![Retention Rate](../../images/retention_rate.png)