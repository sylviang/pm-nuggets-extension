# Competitive Analysis

_Last updated: 2025-04-13_

**Competitive analysis** is a deep dive into your competitors' strengths, weaknesses, strategies, and offerings.

It supports:
- Product differentiation
- Feature and pricing decisions
- Go-to-market alignment

Keep it lean with SWOT or more advanced frameworks like Porter’s Five Forces.

📘 [Read more](https://hbr.org/2006/01/the-five-competitive-forces-that-shape-strategy)

![Competitive Analysis](../../images/competitive_analysis.png)